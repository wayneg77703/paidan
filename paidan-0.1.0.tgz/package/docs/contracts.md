# paidan contracts

Normative schemas. Engine and adapters are written against these; changes here are breaking and require a `schema_version` bump note.

## 1. Run store layout

Root: `<dataDir>/runs/<run_id>/` (default `<APPDATA>/paidan/runs`).

| file | writer | contents |
|---|---|---|
| `request.json` | CLI at submit | immutable run request (schema below) |
| `state.json` | worker (also CLI cancel fallback / reconcile) | current state record, **atomic write** (tmp + rename), idempotent transitions |
| `events.jsonl` | worker | append-only event log (spawn/stdout-chunk meta/terminal judgment evidence) |
| `result.json` | worker (also CLI cancel fallback / reconcile adoption) | terminal result + evidence, written once, atomic |
| `cancel.request` | CLI at cancel | cancel marker; the worker's watcher (500 ms poll) turns it into a tree kill |
| `prompt.txt` | worker | delivered task text, only for `prompt_delivery: "file"` endpoints |

`run_id`: `run_<yyyymmdd>_<8hex>` (date = submit date, local). Idempotent submit: request fingerprint = sha256(endpoint + cwd + task text + mode); a second submit with an identical fingerprint while a non-terminal run exists returns that run instead of creating a duplicate.

## 2. request.json

```json
{
  "schema_version": "1.0.0",
  "run_id": "run_20260910_a1b2c3d4",
  "fingerprint": "sha256:...",
  "endpoint": "kimi-code",
  "cwd": "D:/work/thing",
  "add_dirs": [],
  "task_file": null,
  "task_text": "...",
  "mode": "workspace-write",
  "model": null,
  "effort": null,
  "resume_session": null,
  "run_timeout_sec": 1800,
  "deliverables": [{ "path": "probe-write.txt", "expected": null }],
  "created_at": "ISO-8601",
  "warnings": ["permission:fs.read is soft on this endpoint, verified_at 2026-09-09"]
}
```

`mode` is one of the presets `read-only | workspace-write | unattended`, or an explicit capability set `{"fs.read": {"roots": [...]}, ...}` (CLI: `--capabilities '{"shell.exec":true,"fs.write":true}'`, mutually exclusive with `--mode`). A capability whose value is `true` or an options object is required; `false`/`null` keys are not. Submit-time rule: any required capability mapped `unsupported` in the endpoint manifest → reject with `PERMISSION_UNSUPPORTED` naming the missing capabilities; `soft` → warning recorded in request.warnings. An explicit set runs the endpoint WITHOUT its preset tier flags (`command.mode_args`/`mode_env` stay unspliced — the engine cannot map an arbitrary set onto native tiers); `cwd_arg` still applies. The fingerprint canonicalizes sets (deep key sort), so key order never duplicates a run.

`run_timeout_sec` is the engine wall-clock cap for the run: the effective value is `--run-timeout` ?? config `defaults.run_timeout_sec` ?? 1800, resolved at submit and stored here; `0` disables the cap. On expiry the worker kills the endpoint tree through the cancel termination path and the terminal state is `failed` with an evidence note `run timeout after Ns`.

## 3. state.json

```json
{
  "schema_version": "1.0.0",
  "run_id": "run_...",
  "state": "pending | running | completed | failed | cancelled | unknown | attention",
  "worker": { "pid": 1234, "started_at": "ISO", "pid_start": "platform start token or null", "endpoint_pid": 5678, "endpoint_pid_start": "platform start token or null" },
  "session": { "handle": "native session id or null", "resumable": true },
  "created_at": "...", "updated_at": "...", "terminal_at": null
}
```

- Terminal states: `completed | failed | cancelled | unknown`. `unknown` is legal and means "evidence insufficient; judge by result.json evidence".
- `attention` is assigned only by reconcile (see §5): a non-terminal run whose worker is gone. Reconcile never restarts anything.

## 4. result.json

```json
{
  "schema_version": "1.0.0",
  "run_id": "run_...",
  "state": "completed",
  "exit_code": 0,
  "final_text": "..." ,
  "evidence": {
    "deliverables": [{ "path": "probe-write.txt", "expected": "...", "found": true }],
    "refusals": [],
    "parser": { "type": "kimi-print-json", "degraded": false },
    "notes": []
  },
  "usage": { "input_tokens": 1, "output_tokens": 2, "cached_input_tokens": null, "cost": null, "source": "provider | endpoint-ledger | unavailable" },
  "session_handle": null,
  "terminal_at": "ISO"
}
```

Judgment order (terminal.js): deliverable evidence → endpoint refusal signals → parser-degraded flag → exit code last. A non-zero exit with complete deliverables can still be `completed` only when the endpoint manifest explicitly declares that shape; default is failed/unknown per evidence.

## 5. Supervisor & reconcile

- Submit spawns a **detached worker** (`node dist/worker.js <run_id>`); the worker spawns the endpoint process and owns events/state/result. CLI never babysits.
- Endpoint spawn resolution (Windows EINVAL-safe) is layered: machine-config override (`endpoints.overrides.<name>.bin`, may point at a JS bundle — spawned via `process.execPath`) → PATH scan (`.EXE` preferred over `.CMD` in one directory) → manifest npm layout (`detect.npm_exe` native binary preferred, then `detect.npm_entry` JS entry via node) under the shim's `node_modules` or the standard npm global roots → manifest well-known install locations (`detect.known_paths`, `{home}`/`{env:NAME}` templates so the repo stays free of machine-absolute literals) → last resort `cmd.exe /d /s /c` with caret-escaped verbatim argv (CR/LF and empty arguments are rejected outright). Doctor, probe and the worker share this one resolution path.
- Cancel: explicit only, three layers. ① The CLI writes a `cancel.request` marker into the run dir; the worker's watcher (500 ms poll) turns it into `terminateEndpointTree` — two phases everywhere: graceful first (`taskkill /PID <pid> /T` without `/F` on Windows, process-group SIGTERM elsewhere), forced after a 5 s grace window. ② If the worker does not reach a terminal state within 15 s of the marker, the CLI kills the endpoint tree itself (after re-verifying the recorded start token) and writes the cancelled terminal record directly (`writeCancelledDirect`; a worker that later finishes the same record wins by content, loses silently otherwise). ③ Reconcile backstops orphaned runs. Accepted limitation: Node stdlib cannot create Windows Job Objects (no FFI) and zero runtime dependencies is an invariant, so a force-killed endpoint may leave orphaned grandchildren; no native helper will be introduced for this.
- Run timeout: the worker enforces `request.run_timeout_sec` as a wall-clock cap on the endpoint process (0 = disabled); expiry reuses the cancel termination path and ends the run `failed` with the note `run timeout after Ns`.
- Reconcile runs at CLI start: scan non-terminal states, worker pid dead → state `attention` with evidence note (a 30 s spawn grace window protects just-launched runs; when the worker is gone but `result.json` already holds a terminal record, reconcile **adopts** that terminal state instead of marking `attention`). Never auto-restart.
- PID-reuse identity: a live pid does not prove the recorded process still exists. The worker records platform start tokens for itself (`pid_start`) and the endpoint (`endpoint_pid_start`) — win32 CIM `CreationDate`, linux `/proc/<pid>/stat` field 22, macOS `ps lstart`; equality is identity, formats are never parsed. Reconcile re-verifies before marking `attention` (mismatch = the recorded worker is gone); cancel re-verifies before any direct `taskkill` (mismatch = already gone, never killed). Query failure or an old record without tokens degrades to pid-only liveness, with a note in events/result — never a crash.

## 6. Endpoint manifest (`endpoints/<name>.json`)

```json
{
  "schema_version": "1.0.0",
  "name": "kimi-code",
  "family": "kimi",
  "detect": { "bin": "kimi", "version_args": ["--version"], "version_re": "kimi[^0-9]*([0-9.]+)",
              "npm_exe": "@scope/pkg/.../bin/real.exe", "npm_entry": "@scope/pkg/cli.js",
              "known_paths": ["{env:ProgramFiles}/App/resources/cli.cjs", "{home}/.tool/bin/cli.js"] },
  "command": {
    "argv": ["{bin}", "-p", "{prompt}", "--output-format", "stream-json"],
    "prompt_delivery": "stdin | argv | file",
    "resume_argv": ["{bin}", "exec", "resume", "{session}", "-"],
    "mode_args": { "workspace-write": ["--some-native-write-flag"] },
    "cwd_arg": null,
    "prompt_cwd_hint": true,
    "env": { "KIMI_CODE_HOME": "{native_default}" }
  },
  "permission": {
    "fs.read":    { "status": "supported", "via": "...", "verified_at": "2026-09-09", "version": "0.42.0" },
    "fs.write":   { "status": "supported", "via": "..." },
    "shell.exec": { "status": "supported", "via": "..." },
    "net.fetch":  { "status": "supported" },
    "interact.ask": { "status": "unverified" },
    "presets": { "read-only": "unsupported", "workspace-write": "supported", "unattended": "supported" },
    "denial_evidence": { "status": "supported|soft|unsupported", "via": "..." }
  },
  "resume": { "kind": "flag", "args": ["--resume", "{session}"], "cross_process": true, "notes": "..." },
  "models": { "command": null, "parse": "kimi-native-config", "connections": [] },
  "effort": { "options": ["low", "high"], "arg": ["--effort", "{effort}"], "default": null,
              "status": "supported", "verified_at": "2026-09-10", "version": "2.1.260" },
  "parser": "kimi-print",
  "native_preflight": { "file": "{home}/.tool/settings.json", "require_allow": ["read_file(*)"] },
  "capabilities": { "background_native": false, "cancel_native": false, "max_run_sec": 1800 }
}
```

`native_preflight` (optional) declares a native settings file and the allow rules an endpoint needs (`{"file": "{home}/.../settings.json", "require_allow": [...]}`; `file` follows the `known_paths` template rules). The engine only ever reads it: `doctor` reports `ok | {missing: [...]} | unreadable` per endpoint, and `run` records a request warning when rules are missing — never a refusal, never a write (invariant 4).

`models` governs model discovery: `parse` is only a provenance label stored in the cache entry's `source` — the discovery code always lives in the endpoint's `parser` module (`discoverModels()`), never in a separate `<models.parse>` module. `models.command` is documentation-only (no code reads it; discovery implementations choose their own mechanism — native config read, CLI query, etc.).

`{model}` and `{session}` argv substitutions are charset-validated before splicing (`/^[A-Za-z0-9_][A-Za-z0-9_.:/-]{0,127}$/`, which also rules out a leading `-`): a model alias from discovery/cache or a session handle from endpoint output that fails the check is rejected (`MANIFEST_INVALID` at submit, run `failed` with a note in the worker) instead of being spliced into argv. Model discovery results that fail the same check are dropped from the cache with a note.

`capabilities.max_run_sec` (optional number|null) is documentation-only: the endpoint's own total-time cap (omp's native 30m → `1800`; dsh has none → `null`, the engine cap backstops). The enforcing timeout is always the engine's `run_timeout_sec` (§2).

`effort` (optional object) declares an effort/intensity selection: `{"options": [...], "arg": ["--effort", "{effort}"], "env": {"VAR": "{effort}"}, "default": null, "status", "verified_at", "version", "notes"}`. `options` are the only accepted values (each must survive argv substitution). Delivery is argv (`arg`, spliced with `{effort}` replaced after `model_arg`, fresh and resume alike) and/or env (`env`, values contain `{effort}`, applied by buildEnv on top of `command.env`/`mode_env`) — at least one form must exist. Absent block = the endpoint has no effort selection and any configured effort is an error. The effort resolves as `--effort` ?? `defaults.efforts[endpoint]` ?? `defaults.effort` ?? null (native default); submit rejects an endpoint without a block (`EFFORT_UNSUPPORTED`) or a value outside `options` (`EFFORT_INVALID`). Declared today: claude-code `--effort` (low/medium/high/xhigh/max), codex `-c model_reasoning_effort=` (minimal/low/medium/high/xhigh, argv form; the local config may additionally enable quota-heavy max/ultra — live-verified once, kept out of the picker), kimi-code `KIMI_MODEL_THINKING_EFFORT` (low/high/max, env form — 0.42.0 has no CLI flag; the env var overrides the native config's top-level `effort` key), omp `--thinking` (off/minimal/low/medium/high/xhigh/max/auto), opencode `--variant` (minimal/high/max, provider-specific per `--help`). agy carries effort inside the model alias (flash-high/medium/low); zcode/dsh have no headless effort surface.

`status` ∈ `supported | soft | unsupported | unverified`. `soft` = endpoint claims it but enforcement is doubtful (e.g. intent-only modes); always surfaces as a submit warning.

`command.mode_args` splices per-preset flag fragments (e.g. codex `-s read-only` vs `-s workspace-write`, claude `--permission-mode …`); a manifest that declares `mode_args` must cover every preset its permission map marks supported. `command.cwd_arg` (optional array, `{cwd}` → run cwd) is consumed by buildArgs and spliced **after** `mode_args`, so a subcommand riding in `mode_args` (codex `exec`, opencode `run`) stays left of the cwd flag — the "security-critical flags never land in the wrong position" invariant. `command.mode_env` (optional per-preset env map, e.g. dsh `read-only` → `DSH_PERMISSION_MODE=read-only`) is spliced by buildEnv on top of static `env`; partial coverage is normal (only tiers needing an env override declare it).

`command.model_arg` (optional array, `{model}` → the configured model) is the endpoint's **headless model selection**: when present, a configured model is spliced with it (after validation); when **absent**, the endpoint takes no model on its command line (its native config owns the model — dsh, zcode) and any configured model is a submit-time `MODEL_UNSUPPORTED` error naming the repair, not a silent drop. The init wizard reads the same flag: `model_selectable = model_arg !== undefined` gates the per-endpoint default-model prompt and validation. The `effort` block (defined below) follows the same pattern: an absent block means no headless effort selection (`EFFORT_UNSUPPORTED` when configured).

`command.env` value sentinels: `"{native_default}"` = never set the variable; `"{unset}"` = delete the inherited variable (opencode strips `PWD`, which otherwise re-anchors the project root). Keys starting with `_` are documentation and are never exported to the child process.

`command.prompt_cwd_hint` (optional boolean, default false): the worker appends one fixed line — `The current working directory is <request.cwd>. Use absolute paths for all file operations.` — to the delivered task text on every delivery form (argv/stdin/file) and equally on resume (`resume_argv` `{prompt}`). `request.json` stores the original text and the fingerprint is unchanged (cwd is already inside it); `events.jsonl` records a `prompt_cwd_hint appended` note. For endpoints whose tools ignore the spawn cwd — agy 1.2.0 `run_command` starts in its own scratch dir, so deliverables only land reliably via absolute paths.

`command.prompt_max_bytes` (optional positive number, default 24000): only for `prompt_delivery: "argv"`. At submit the engine builds the final argv (hint included) and rejects with `TASK_TOO_LONG` when the command line (bin + space-joined args) exceeds the limit in UTF-8 bytes — Windows CreateProcess caps it at 32767 chars and a 26 KiB prompt has died in practice. The error names the endpoint's delivery form and the limit and suggests a shorter task or a stdin/file-delivery endpoint.

`command.resume_argv` (optional) fully replaces `command.argv` on resume runs: `{session}`/`{prompt}` are substituted and `model_arg` is still spliced, but `mode_args`/`add_dir_arg` are not (a resumed session restores its original tier — e.g. `codex exec resume` accepts neither `-s` nor `--add-dir`). Without `resume_argv`, `resume.args` flags are spliced and `mode_args` are re-passed (claude semantics). `detect.npm_exe`/`npm_entry` are package-relative paths under the npm install tree (never machine-absolute), used when PATH exposes only a script shim. `detect.known_paths` (optional) lists well-known per-platform install locations as templates that must start with `{home}` or `{env:NAME}` and contain no `..`; unset env tokens skip the candidate, and a hit resolves with `resolved_from: "known-path"`.

Parser modules are convention-loaded: `parser: "<name>"` resolves to `src/endpoints/<name>.ts` exporting `createParser()` + `detectRefusals(stderrText, exitCode)` (+ optional `discoverModels()`). Parse results carry `refusals: string[]` for in-band refusal evidence (claude `permission_denials`, codex in-band error items); the worker merges them with `detectRefusals` output into `result.json` evidence — refusal is evidence, never automatic failure. Adding an endpoint = one manifest + one parser module + golden fixtures; no engine file changes.

## 7. CLI verbs (output always JSON)

`run | get [--wait] [--timeout s] | cancel | list | models [--refresh] | doctor | probe | init [--yes] | help`

`run` selects the permission tier with `--mode <preset>` (default `workspace-write`) or `--capabilities '<json>'` (explicit set; mutually exclusive with `--mode`, see §2), bounds wall time with `--run-timeout <秒>` (`0` disables, see §2), and refuses over-long argv prompts with `TASK_TOO_LONG` (§6 `prompt_max_bytes`). The model resolves as `--model` ?? `defaults.models[endpoint]` ?? `defaults.model` (per-endpoint defaults win over the global one; never a cross-connection fallback) — a resolved model against an endpoint with no `command.model_arg` is refused with `MODEL_UNSUPPORTED` naming the repair (the endpoint's native config owns the model). The effort resolves as `--effort` ?? `defaults.efforts[endpoint]` ?? `defaults.effort` ?? null (native default; `EFFORT_UNSUPPORTED` when the endpoint declares no effort block, `EFFORT_INVALID` for a value outside its `options`, §6). "Native default" is a real, observable value, not a black box: `doctor` and the init wizard carry a **read-only native-defaults probe** (`native_defaults` / `InitEndpointInfo.native`; parser modules may export `readNativeDefaults()` — top-level config keys only, never written) and the wizard's first effort choice renders it, e.g. `(native default, currently max)`. A run whose endpoint would spawn through a cmd.exe shim is refused with `SPAWN_UNSUPPORTED` when `prompt_delivery` is `argv` — npm `.cmd` shims pass arguments through a bare `%*`, which re-splits them on spaces and lets the task text smuggle real CLI flags (verified empirically); the refusal names the repair (`endpoints.overrides.<name>.bin` pointing at the native binary/JS bundle, or installing so a native exe is on PATH). The same check backstops inside the worker (run ends `failed` with a `spawn-refused` event) for paths that bypass submit. Fingerprint dedup (§1) ignores model/effort: a re-submit that only changes those returns the original run with a warning naming the differing field.

Error codes (CLI envelope `error.code`; worker fail codes land in `result.evidence.notes` as `<code>: <message>`):

| CLI | worker | meaning |
|---|---|---|
| `ARGS_INVALID` | | flag/positional misuse (incl. parseArgs rejections) |
| `ENDPOINT_REQUIRED` / `ENDPOINT_UNKNOWN` / `ENDPOINT_DISABLED` | | no usable endpoint (flag/config/enabled) |
| `CONFIG_INVALID` | `MANIFEST_LOAD_FAILED` | config.json invalid / a manifest failed to load |
| `PERMISSION_UNSUPPORTED` | | mode/capabilities the endpoint cannot enforce |
| `MODE_INVALID` / `TASK_REQUIRED` / `TASK_TOO_LONG` | | mode name / missing task / argv over the byte guard |
| `MODEL_UNSUPPORTED` / `MODELS_QUERY_FAILED` / `UNSUPPORTED` | | model the endpoint cannot take / discovery failed / no such feature |
| `EFFORT_UNSUPPORTED` / `EFFORT_INVALID` | | endpoint has no effort block / value outside its options |
| `SPAWN_UNSUPPORTED` | `SPAWN_UNSUPPORTED` | cmd-shim + argv delivery refused (submit / worker backstop) |
| `RUN_NOT_FOUND` | | no such run_id |
| `WORKER_SPAWN_FAILED` | `SPAWN_FAILED` / `ENDPOINT_BIN_NOT_FOUND` | worker failed to launch / endpoint failed to spawn |
| `INIT_INTERACTIVE_REQUIRED` / `INIT_ABORTED` | | init needs a TTY / init aborted by user (exit 130) |
| `MANIFEST_INVALID` | `MANIFEST_INVALID` / `WORKER_ERROR` | manifest rule violated / worker crashed |
| `INTERNAL` | | anything unclassified (report it) |

- `doctor`: endpoint detection results, versions, permission map status, native_preflight outcome, **native_defaults** (read-only probe: the model/effort each endpoint's own home currently carries), config/data dir paths, db status, models-cache ages. This is the compatibility-matrix generator.
- `probe`: per endpoint, P1 write / P2 read-only refusal / P3 resume contract probes against the installed agent; refreshes `verified_at` fields on success (local calendar date).
- `models`: cache-first against `<dataDir>/models-cache/<endpoint>.json` (`{schema_version, endpoint, fetched_at, version, source, models, notes}`); `--refresh` forces a live query and writes through. A failed refresh serves the last successful cache with `stale: true`; a successful empty list overwrites (never borrows the old cache).
- `init`: first-run wizard. Interactive on a TTY: skipped non-detected endpoints (with repair hints, not enable-able), then a checkbox multi-select for endpoints (space toggles, enter confirms; arrows wrap, numbers, a=toggle-all, i=invert), an arrow-key menu for the default endpoint, a **per-endpoint default-model prompt for every enabled endpoint that can take a model headless** (`model_selectable = command.model_arg !== undefined`; endpoints like dsh/zcode whose native config owns the model get a note instead, single-model endpoints auto-pick, model-less endpoints keep the native default), a **per-endpoint default-effort prompt where the endpoint declares an effort block** (first choice is always `(native default)` = no config entry), and a checkbox multi-select of hosts for the skill install (already-installed hosts marked; `skills/hosts.json` lists all eight agents' user-scope skills dirs, so every agent can be both delegatee and host). stderr must be a TTY for the raw-mode widgets; otherwise the wizard falls back to line-based numeric prompts. Writes config.json; existing config is backed up first **and merged** — the wizard owns `endpoints.enabled` + the wizard-owned defaults keys (`endpoint`, `model`, `models`, `efforts`; single source `WIZARD_DEFAULTS_KEYS` in config.ts). **The wizard never writes the global `defaults.model`** — a global fallback poisons endpoints with no headless model selection, so re-init clears a hand-set one deliberately; the hand-set global `defaults.effort` is not wizard-owned and survives, as do machine-local keys (`endpoints.overrides`, `dataDir`, `defaults.run_timeout_sec`, ...). Non-TTY callers get `INIT_INTERACTIVE_REQUIRED` plus current state JSON; `--yes` enables all detected endpoints, **leaves every model/effort at the endpoint's native default** (the agent's own home carries them — a paidan-side first-discovered default is an override layer that silently changes native behavior), and installs the skill into every detected host; `--yes --effort <level>` additionally applies that level to every detected endpoint whose declared options include it (the ok envelope reports `effort_applied_to` / `effort_skipped`); `--yes --hosts <names>` restricts the skill install to exactly those hosts (an agent-collected subset must be faithfully installed). The survey phase persists nothing — model caches are written only after answers commit, so an aborted init (`INIT_ABORTED`, exit 130) and a non-TTY survey both leave the disk untouched. The **global `defaults.effort` is deprecated and wizard-cleared** like the global `model`: it poisons endpoints without an effort block and silently overrides a per-endpoint native choice; hand-set values are removed on re-init (config.json loading still accepts the key for compatibility). The decision logic lives in `engine/init-plan.ts` (UI-free, incl. `planEndpointDefaultQuestions`) so a console GUI reuses it. After the config write, init offers to install the paidan skill (`skills/paidan/SKILL.md`, payload listed in `skills/hosts.json`) into each selected host's user-scope skills dir — per-host multi-select on a TTY, all detected hosts under `--yes`; installs are atomic copies reported as created/updated/unchanged, and only ever happen on explicit selection (invariant 4: no silent writes to an agent's native home). The payload's frontmatter is adapted per host spec (`frontmatter_fields` in `skills/hosts.json`: kimi-code reads `name`/`description`/`whenToUse`; every other verified host spec is `name`+`description` only).

## 8. usage.db (node:sqlite)

Table `usage(run_id TEXT PRIMARY KEY, endpoint TEXT, connection TEXT, model TEXT, input_tokens INTEGER, cached_input_tokens INTEGER, output_tokens INTEGER, cost REAL, source TEXT, recorded_at TEXT)`. `source` ∈ `provider | endpoint-ledger | unavailable` — three-state, never fabricate zeros. `provider` = the endpoint's own output stream carried usage; `endpoint-ledger` = observed from the endpoint's native on-disk ledger (kimi: `<KIMI_CODE_HOME|~/.kimi-code>/session_index.jsonl` → `<sessionDir>/agents/*/wire.jsonl` `usage.record` rows, summed). Resume runs are summed from a pre-spawn byte cursor the worker captures per wire file (bytes after the cursor are this run's delta; wires created during the run are summed whole); a resume run without a cursor stays honestly `unavailable`. No cross-connection aggregation games: accounting is per connection. `connection` is derived from the model alias: the segment before the first `/` (e.g. `deepseek/deepseek-v4-flash` → `deepseek`), NULL when the alias has no `/` (claude/codex-style aliases today) — no cross-connection inference beyond that prefix. `cost` mirrors `result.json` usage.cost: the provider-reported total (claude `total_cost_usd`), NULL for endpoints without a cost concept (kimi ledger and every other endpoint today).
